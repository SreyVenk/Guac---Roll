package com.csc340.crud_api_jpa_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudApiJpaDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
