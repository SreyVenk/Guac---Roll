package com.csc340.crud_api_jpa_demo.service;

public class SysAdminService {
}
