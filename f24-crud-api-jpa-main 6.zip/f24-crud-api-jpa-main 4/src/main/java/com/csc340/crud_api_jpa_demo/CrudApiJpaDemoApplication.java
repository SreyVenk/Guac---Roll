package com.csc340.crud_api_jpa_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudApiJpaDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudApiJpaDemoApplication.class, args);
	}

}
