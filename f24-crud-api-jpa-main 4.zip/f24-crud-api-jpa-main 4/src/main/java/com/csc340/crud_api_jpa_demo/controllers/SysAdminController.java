package com.csc340.crud_api_jpa_demo.controllers;

public class SysAdminController {
}
