package com.csc340.crud_api_jpa_demo.service;

import com.csc340.crud_api_jpa_demo.objects.Reviews;
import com.csc340.crud_api_jpa_demo.repository.ReviewsRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewsService {

    @Autowired
    private ReviewsRepository reviewsRepository;

    public List<Reviews> getAllReviews() {
        return reviewsRepository.findAll();
    }

    public Reviews saveReview(Reviews review) {
        return reviewsRepository.save(review);
    }

    public Reviews updateReview(int id, Reviews reviewDetails) {
        Reviews review = reviewsRepository.findById(id).orElseThrow();
        review.setCartId(reviewDetails.getCartId());
        review.setReviewerId(reviewDetails.getReviewerId());
        review.setDetails(reviewDetails.getDetails());
        review.setUpdatedAt(reviewDetails.getUpdatedAt());
        review.setStatus(reviewDetails.getStatus());
        review.setRating(reviewDetails.getRating());
        return reviewsRepository.save(review);
    }

    public void deleteReview(int id) {
        reviewsRepository.deleteById(id);
    }
}
