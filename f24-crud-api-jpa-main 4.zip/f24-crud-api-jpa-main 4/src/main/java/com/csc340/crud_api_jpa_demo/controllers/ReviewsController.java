package com.csc340.crud_api_jpa_demo.controllers;

import com.csc340.crud_api_jpa_demo.objects.Reviews;
import com.csc340.crud_api_jpa_demo.service.ReviewsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reviews")
public class ReviewsController {

    @Autowired
    private ReviewsService reviewsService;

    @GetMapping
    public List<Reviews> getAllReviews() {
        return reviewsService.getAllReviews();
    }

    @PostMapping
    public Reviews createReview(@RequestBody Reviews review) {
        return reviewsService.saveReview(review);
    }

    @PutMapping("/{id}")
    public Reviews updateReview(@PathVariable int id, @RequestBody Reviews reviewDetails) {
        return reviewsService.updateReview(id, reviewDetails);
    }

    @DeleteMapping("/{id}")
    public void deleteReview(@PathVariable int id) {
        reviewsService.deleteReview(id);
    }
}
